# AutoDeface
Deface

# Screenshot
<img src="Screenshot_2018-11-30-00-40-39.png"/>

# Installion And Using Auto Deface
```
$ apt update
$ apt upgrade
$ apt install git
$ git clone https://github.com/TermuxOfficial/AutoDeface
$ cd AutoDeface
$ chmod +x *
$ ./deface.sh
```

# Metodh
vuln webdav

# Website
https://termuxindonesia.wordpress.com
https://github.com/TermuxOfficial/AutoDeface/wiki/Auto-Deface-Wiki
